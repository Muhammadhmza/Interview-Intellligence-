import * as pdfjsLib from 'pdfjs-dist';
import * as mammoth from 'mammoth';

// Set worker source for pdfjs-dist using a reliable CDN that matches the version
// In newer versions of pdfjs-dist (4+), the worker is often an mjs file
const PDFJS_VERSION = '5.6.205';
// Try unpkg as it's often more reliable for specific package files
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${PDFJS_VERSION}/build/pdf.worker.min.mjs`;

export async function parsePdf(file: File): Promise<string> {
  try {
    console.log('Starting PDF parse for:', file.name);
    const arrayBuffer = await file.arrayBuffer();
    
    // Check if pdfjsLib is loaded
    if (!pdfjsLib.getDocument) {
      throw new Error('pdfjs-dist library not fully loaded');
    }

    const loadingTask = pdfjsLib.getDocument({ 
      data: arrayBuffer,
      useWorkerFetch: true,
      isEvalSupported: false,
    });
    
    const pdf = await loadingTask.promise;
    console.log(`PDF loaded successfully, pages: ${pdf.numPages}`);
    
    let text = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      const pageText = content.items
        .map((item: any) => (item as any).str)
        .join(' ');
      text += pageText + '\n';
    }
    
    if (!text.trim()) {
      console.warn('PDF parsed but no text was extracted. It might be an image-based PDF.');
    }
    
    console.log('PDF parse complete, text length:', text.length);
    return text;
  } catch (error) {
    console.error('Error parsing PDF:', error);
    throw new Error(`PDF parsing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function parseDocx(file: File): Promise<string> {
  try {
    console.log('Starting DOCX parse for:', file.name);
    const arrayBuffer = await file.arrayBuffer();
    
    // Check if mammoth is loaded
    if (!mammoth || !mammoth.extractRawText) {
      // Try a different import pattern if the first one failed
      console.warn('Mammoth not found with current import, trying fallback...');
      throw new Error('mammoth library not fully loaded');
    }

    // mammoth.extractRawText works with arrayBuffer in browser
    const result = await mammoth.extractRawText({ arrayBuffer });
    
    if (result.messages && result.messages.length > 0) {
      console.warn('Mammoth messages:', result.messages);
    }
    
    console.log('DOCX parse complete, text length:', result.value.length);
    return result.value;
  } catch (error) {
    console.error('Error parsing DOCX:', error);
    throw new Error(`DOCX parsing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function parseFile(file: File): Promise<string> {
  if (!file) throw new Error('No file provided');
  
  const extension = file.name.split('.').pop()?.toLowerCase();
  console.log(`Parsing file: ${file.name} with extension: ${extension}, size: ${file.size} bytes`);
  
  if (extension === 'pdf') {
    return parsePdf(file);
  } else if (extension === 'docx') {
    return parseDocx(file);
  } else if (extension === 'txt' || extension === 'md') {
    return file.text();
  } else {
    // Try to read as text for unknown extensions
    console.warn(`Unknown extension: ${extension}, attempting to read as text`);
    return file.text();
  }
}
