import React, { useState, useRef, ReactNode, useEffect, ChangeEvent, MouseEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Briefcase, 
  FileText, 
  Building2, 
  MapPin, 
  Search, 
  Sparkles, 
  ChevronRight, 
  AlertCircle, 
  CheckCircle2, 
  Target, 
  Zap, 
  Brain, 
  MessageSquare, 
  TrendingUp, 
  ShieldAlert, 
  Users, 
  Mic2,
  ArrowRight,
  Loader2,
  Download,
  Upload,
  Link as LinkIcon,
  History,
  LogIn,
  LogOut,
  Globe,
  Share2,
  Copy,
  Check,
  Info,
  Wand2
} from 'lucide-react';
import { generateInterviewReport, extractJdDetails } from './services/geminiService';
import { InterviewReport } from './types';
import { auth, db } from './firebase';
import { signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User, signOut } from 'firebase/auth';
import { collection, addDoc, query, where, getDocs, orderBy, doc, getDoc } from 'firebase/firestore';
import { parseFile } from './lib/fileParser';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

export default function App() {
  const [cv, setCv] = useState('');
  const [jd, setJd] = useState('');
  const [jdUrl, setJdUrl] = useState('');
  const [company, setCompany] = useState('');
  const [role, setRole] = useState('');
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<InterviewReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loadingMessage, setLoadingMessage] = useState('Analyzing your profile...');
  const [user, setUser] = useState<User | null>(null);
  const [pastReports, setPastReports] = useState<any[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  const [cvFileName, setCvFileName] = useState('');
  const [jdFileName, setJdFileName] = useState('');
  const [reportId, setReportId] = useState<string | null>(null);
  const [isSharedView, setIsSharedView] = useState(false);
  const [copied, setCopied] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [isAuthLoading, setIsAuthLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setIsAuthLoading(false);
      if (u) {
        fetchPastReports(u.uid);
      }
    });

    // Check for shared report ID in URL
    const params = new URLSearchParams(window.location.search);
    const sharedId = params.get('reportId');
    if (sharedId) {
      loadSharedReport(sharedId);
    }

    return () => unsubscribe();
  }, []);

  // Persistence for inputs
  useEffect(() => {
    const savedCv = localStorage.getItem('cv');
    const savedJd = localStorage.getItem('jd');
    const savedJdUrl = localStorage.getItem('jdUrl');
    const savedCompany = localStorage.getItem('company');
    const savedRole = localStorage.getItem('role');
    const savedLocation = localStorage.getItem('location');

    if (savedCv) setCv(savedCv);
    if (savedJd) setJd(savedJd);
    if (savedJdUrl) setJdUrl(savedJdUrl);
    if (savedCompany) setCompany(savedCompany);
    if (savedRole) setRole(savedRole);
    if (savedLocation) setLocation(savedLocation);
  }, []);

  useEffect(() => {
    localStorage.setItem('cv', cv);
    localStorage.setItem('jd', jd);
    localStorage.setItem('jdUrl', jdUrl);
    localStorage.setItem('company', company);
    localStorage.setItem('role', role);
    localStorage.setItem('location', location);
  }, [cv, jd, jdUrl, company, role, location]);

  const loadSharedReport = async (id: string) => {
    setLoading(true);
    setLoadingMessage('Loading shared report...');
    try {
      const docRef = doc(db, 'reports', id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        setReport(data.report);
        setCompany(data.company);
        setRole(data.role);
        setLocation(data.location);
        setReportId(id);
        setIsSharedView(true);
      } else {
        setError("Shared report not found.");
      }
    } catch (err) {
      console.error("Error loading shared report:", err);
      setError("Failed to load shared report.");
    } finally {
      setLoading(false);
    }
  };

  const fetchPastReports = async (uid: string) => {
    try {
      const q = query(
        collection(db, 'reports'),
        where('userId', '==', uid),
        orderBy('createdAt', 'desc')
      );
      const querySnapshot = await getDocs(q);
      const reports = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setPastReports(reports);
    } catch (err) {
      console.error("Error fetching reports:", err);
    }
  };

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error("Login error:", err);
      setError("Failed to login with Google.");
    }
  };

  const handleLogout = () => {
    signOut(auth);
    localStorage.clear();
  };

  const handleCvUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    console.log('CV upload triggered:', file?.name);
    if (file) {
      setCvFileName(file.name);
      try {
        const text = await parseFile(file);
        console.log('CV parsed successfully, length:', text.length);
        setCv(text);
      } catch (err: any) {
        console.error("CV parse error:", err);
        setError(err.message || "Failed to parse CV file.");
      }
    }
  };

  const handleJdUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    console.log('JD upload triggered:', file?.name);
    if (file) {
      setJdFileName(file.name);
      try {
        const text = await parseFile(file);
        console.log('JD parsed successfully, length:', text.length);
        setJd(text);
      } catch (err: any) {
        console.error("JD parse error:", err);
        setError(err.message || "Failed to parse JD file.");
      }
    }
  };

  const saveReport = async (data: InterviewReport) => {
    if (!user) return null;
    try {
      const docRef = await addDoc(collection(db, 'reports'), {
        userId: user.uid,
        company,
        role,
        location,
        createdAt: new Date().toISOString(),
        report: data
      });
      fetchPastReports(user.uid);
      return docRef.id;
    } catch (err) {
      console.error("Error saving report:", err);
      return null;
    }
  };

  const handleSelectReport = (pastReport: any) => {
    setReport(pastReport.report);
    setCompany(pastReport.company);
    setRole(pastReport.role);
    setLocation(pastReport.location);
    setReportId(pastReport.id);
    setShowHistory(false);
    setIsSharedView(false);
  };

  const messages = [
    "Extracting key skills from your CV...",
    "Deep-diving into the Job Description...",
    "Scanning company intelligence and market position...",
    "Identifying potential skill gaps...",
    "Crafting elite interview strategies...",
    "Generating high-impact question bank...",
    "Simulating mock interview scenarios...",
    "Finalizing your personalized intelligence report..."
  ];

  const handleGenerate = async () => {
    // Client-side validation
    const errors = [];
    if (!cv.trim()) errors.push("CV content is required.");
    if (!jd.trim() && !jdUrl.trim()) errors.push("Job Description or JD URL is required.");
    if (!company.trim()) errors.push("Company Name is required.");
    if (!role.trim()) errors.push("Role is required.");

    if (errors.length > 0) {
      setError(errors.join(" "));
      return;
    }

    setLoading(true);
    setError(null);
    setReport(null);
    setReportId(null);
    setIsSharedView(false);

    let msgIndex = 0;
    const interval = setInterval(() => {
      setLoadingMessage(messages[msgIndex % messages.length]);
      msgIndex++;
    }, 3000);

    try {
      const result = await generateInterviewReport(cv, jd, company, role, location, jdUrl);
      setReport(result);
      if (user) {
        const id = await saveReport(result);
        setReportId(id);
      }
    } catch (err) {
      console.error(err);
      setError("Failed to generate report. Please try again.");
    } finally {
      clearInterval(interval);
      setLoading(false);
    }
  };

  const handleExportPdf = async () => {
    const reportElement = document.getElementById('interview-report');
    if (!reportElement) {
      setError('Interview report element not found.');
      return;
    }

    setLoading(true);
    setLoadingMessage('Preparing PDF...');

    try {
      const canvas = await html2canvas(reportElement, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#020617', // Match slate-950
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      const canvasWidth = canvas.width;
      const canvasHeight = canvas.height;

      const ratio = pdfWidth / canvasWidth;
      const imgHeight = canvasHeight * ratio;

      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, imgHeight);
      heightLeft -= pdfHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, imgHeight);
        heightLeft -= pdfHeight;
      }

      pdf.save(`${company || 'interview'}-${role || 'report'}.pdf`);
    } catch (err: any) {
      console.error('PDF export error:', err);
      setError(`Failed to export PDF: ${err.message || 'Unknown error'}`);
    } finally {
      setLoading(false);
      setLoadingMessage('Analyzing your profile...');
    }
  };

  const handleShare = () => {
    if (!reportId) return;
    const shareUrl = `${window.location.origin}${window.location.pathname}?reportId=${reportId}`;
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyReport = () => {
    if (!report) return;
    const reportText = JSON.stringify(report, null, 2);
    navigator.clipboard.writeText(reportText);
    alert('Report data copied to clipboard!');
  };

  const handleDeleteReport = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this report?')) return;
    
    try {
      const { deleteDoc, doc } = await import('firebase/firestore');
      await deleteDoc(doc(db, 'reports', id));
      setPastReports(prev => prev.filter(r => r.id !== id));
      if (reportId === id) {
        setReport(null);
        setReportId(null);
      }
    } catch (err) {
      console.error("Error deleting report:", err);
      setError("Failed to delete report.");
    }
  };

  const handleClearAllHistory = async () => {
    if (!user) return;
    if (!confirm('Are you sure you want to clear ALL your report history? This cannot be undone.')) return;
    
    try {
      const { deleteDoc, doc } = await import('firebase/firestore');
      const deletePromises = pastReports.map(r => deleteDoc(doc(db, 'reports', r.id)));
      await Promise.all(deletePromises);
      setPastReports([]);
      setReport(null);
      setReportId(null);
      setShowHistory(false);
    } catch (err) {
      console.error("Error clearing history:", err);
      setError("Failed to clear history.");
    }
  };

  const handleExtractJd = async () => {
    if (!jd && !jdUrl) {
      setError("Please provide JD text or a URL first.");
      return;
    }
    setExtracting(true);
    try {
      const details = await extractJdDetails(jd, jdUrl);
      if (details.company) setCompany(details.company);
      if (details.role) setRole(details.role);
      if (details.location) setLocation(details.location);
    } catch (err) {
      console.error("Extraction error:", err);
    } finally {
      setExtracting(false);
    }
  };

  if (isAuthLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <Loader2 className="w-12 h-12 text-indigo-500 animate-spin" />
      </div>
    );
  }

  if (!user && !isSharedView) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-slate-950 text-white">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full text-center space-y-8"
        >
          <div className="relative inline-block">
            <div className="w-24 h-24 rounded-3xl bg-indigo-500/20 flex items-center justify-center text-indigo-400 mx-auto">
              <Brain className="w-12 h-12" />
            </div>
            <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center text-slate-950">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>
          
          <div className="space-y-2">
            <h1 className="text-4xl font-bold font-display tracking-tight">
              Interview <span className="gradient-text">Intelligence</span>
            </h1>
            <p className="text-slate-400">
              The elite career strategist engine. Sign in to unlock 19 years of recruitment logic and start your preparation.
            </p>
          </div>

          <button 
            onClick={handleLogin}
            className="w-full flex items-center justify-center gap-3 px-8 py-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-lg transition-all shadow-xl shadow-indigo-500/20 group"
          >
            <LogIn className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            <span>Sign In with Google</span>
          </button>

          <div className="pt-8 border-t border-slate-800 flex justify-center gap-8 text-slate-500 text-sm">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4" />
              <span>Secure</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              <span>Fast</span>
            </div>
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              <span>AI-Powered</span>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <header className="pt-12 pb-8 px-6 text-center relative">
        <div className="absolute top-4 right-6 flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setShowHistory(!showHistory)}
                className="p-2 rounded-full bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white transition-colors"
                title="History"
              >
                <History className="w-5 h-5" />
              </button>
              <div className="h-8 w-8 rounded-full border border-indigo-500/50 overflow-hidden">
                <img src={user.photoURL || ''} alt="" className="w-full h-full object-cover" />
              </div>
              <button onClick={handleLogout} className="text-slate-400 hover:text-white transition-colors">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <button 
              onClick={handleLogin}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium transition-colors"
            >
              <LogIn className="w-4 h-4" />
              <span>Sign In</span>
            </button>
          )}
        </div>
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm font-medium mb-4"
        >
          <Sparkles className="w-4 h-4" />
          <span>AI-Powered Career Intelligence</span>
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-5xl md:text-7xl font-bold font-display tracking-tight mb-4"
        >
          Interview <span className="gradient-text">Intelligence</span>
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-slate-400 max-w-2xl mx-auto text-lg"
        >
          Elite career strategist engine. Bridge the gap between your CV and the JD with 15+ years of recruitment logic.
        </motion.p>
      </header>

      <main className="max-w-6xl mx-auto px-6">
        {!report && !loading && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8"
          >
            {/* Left Column: Inputs */}
            <div className="space-y-6">
              <div className="glass-card">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-400">
                    <FileText className="w-5 h-5" />
                  </div>
                  <h2 className="text-xl font-bold font-display">Candidate CV</h2>
                  <div className="flex items-center gap-2">
                    <Tooltip text="Upload your CV in PDF or DOCX format. We'll extract the text for analysis.">
                      <label className="cursor-pointer p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 hover:bg-indigo-500/20 transition-all">
                        <Upload className="w-4 h-4" />
                        <input type="file" className="hidden" accept=".pdf,.docx" onChange={handleCvUpload} />
                      </label>
                    </Tooltip>
                    {cvFileName && <span className="text-xs text-slate-400 truncate max-w-[100px]">{cvFileName}</span>}
                  </div>
                </div>
                <Tooltip text="Paste your CV content here if you prefer not to upload a file.">
                  <textarea
                    value={cv}
                    onChange={(e) => setCv(e.target.value)}
                    placeholder="Paste your CV text here or upload a file..."
                    className="w-full h-64 bg-slate-900/50 border border-slate-800 rounded-xl p-4 text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all resize-none"
                  />
                </Tooltip>
              </div>

              <div className="glass-card">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-xl bg-pink-500/20 flex items-center justify-center text-pink-400">
                    <Briefcase className="w-5 h-5" />
                  </div>
                  <h2 className="text-xl font-bold font-display">Job Description</h2>
                  <div className="flex items-center gap-2">
                    <Tooltip text="Upload the Job Description file (PDF/DOCX).">
                      <label className="cursor-pointer p-2 rounded-lg bg-pink-500/10 border border-pink-500/20 text-pink-400 hover:bg-pink-500/20 transition-all">
                        <Upload className="w-4 h-4" />
                        <input type="file" className="hidden" accept=".pdf,.docx" onChange={handleJdUpload} />
                      </label>
                    </Tooltip>
                    {jdFileName && <span className="text-xs text-slate-400 truncate max-w-[100px]">{jdFileName}</span>}
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <LinkIcon className="h-4 w-4 text-slate-500" />
                    </div>
                    <Tooltip text="Enter the URL of the job posting. Our AI will try to read the content.">
                      <input
                        type="url"
                        value={jdUrl}
                        onChange={(e) => setJdUrl(e.target.value)}
                        placeholder="Or enter JD URL..."
                        className="w-full pl-10 bg-slate-900/50 border border-slate-800 rounded-xl py-2 px-4 text-slate-300 focus:outline-none focus:ring-2 focus:ring-pink-500/50 transition-all"
                      />
                    </Tooltip>
                  </div>
                  <Tooltip text="Paste the full job description text here for the most accurate analysis.">
                    <textarea
                      value={jd}
                      onChange={(e) => setJd(e.target.value)}
                      placeholder="Paste the Job Description here or upload a file..."
                      className="w-full h-48 bg-slate-900/50 border border-slate-800 rounded-xl p-4 text-slate-300 focus:outline-none focus:ring-2 focus:ring-pink-500/50 transition-all resize-none"
                    />
                  </Tooltip>
                </div>
              </div>
            </div>

            {/* Right Column: Details & Action */}
            <div className="space-y-6">
              <div className="glass-card">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400">
                      <Building2 className="w-5 h-5" />
                    </div>
                    <h2 className="text-xl font-bold font-display">Target Details</h2>
                  </div>
                  <Tooltip text="Auto-extract Company, Role, and Location from the JD content above.">
                    <button 
                      onClick={handleExtractJd}
                      disabled={extracting || (!jd && !jdUrl)}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all text-xs font-bold"
                    >
                      {extracting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Wand2 className="w-3 h-3" />}
                      Auto-Fill
                    </button>
                  </Tooltip>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1.5">Company Name</label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <Tooltip text="The name of the company you are applying to. Used for company intelligence.">
                        <input
                          type="text"
                          value={company}
                          onChange={(e) => setCompany(e.target.value)}
                          placeholder="e.g. Google, Stripe, Tesla"
                          className="w-full bg-slate-900/50 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all"
                        />
                      </Tooltip>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1.5">Role Applying For</label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <Tooltip text="The specific job title. Critical for tailoring the interview questions.">
                        <input
                          type="text"
                          value={role}
                          onChange={(e) => setRole(e.target.value)}
                          placeholder="e.g. Senior Product Designer"
                          className="w-full bg-slate-900/50 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all"
                        />
                      </Tooltip>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1.5">Location (Optional)</label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <Tooltip text="Helps us suggest other relevant organizations in your area.">
                        <input
                          type="text"
                          value={location}
                          onChange={(e) => setLocation(e.target.value)}
                          placeholder="e.g. Remote, New York, London"
                          className="w-full bg-slate-900/50 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all"
                        />
                      </Tooltip>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-1 rounded-2xl bg-gradient-to-r from-indigo-500 via-pink-500 to-amber-500 shadow-xl shadow-indigo-500/10">
                <Tooltip text="Click to start the deep contextual analysis. This takes about 30-60 seconds.">
                  <button
                    onClick={handleGenerate}
                    className="w-full bg-slate-950 hover:bg-slate-900 text-white font-bold py-6 rounded-[14px] flex items-center justify-center gap-3 transition-all group"
                  >
                    <Zap className="w-6 h-6 text-amber-400 group-hover:scale-110 transition-transform" />
                    <span className="text-xl">Generate Intelligence Report</span>
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </Tooltip>
              </div>

              {error && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center gap-3"
                >
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <p className="text-sm">{error}</p>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}

        {/* Loading State */}
        <AnimatePresence>
          {loading && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xl flex flex-col items-center justify-center p-6 text-center"
            >
              <div className="relative mb-8">
                <div className="w-24 h-24 rounded-full border-4 border-indigo-500/20 border-t-indigo-500 animate-spin" />
                <Brain className="absolute inset-0 m-auto w-10 h-10 text-indigo-400 animate-pulse" />
              </div>
              <motion.h3 
                key={loadingMessage}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-2xl font-bold font-display mb-2"
              >
                {loadingMessage}
              </motion.h3>
              <p className="text-slate-400">Our AI engine is processing 19 years of recruitment logic...</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Report Display */}
        {report && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-12"
            id="interview-report"
          >
            {/* Summary Bar */}
            <div className="flex flex-wrap items-center justify-between gap-6 glass-card border-indigo-500/30">
              <div className="flex items-center gap-4">
                <div>
                  <h2 className="text-3xl font-bold font-display">{role}</h2>
                  <p className="text-slate-400 flex items-center gap-2">
                    <Building2 className="w-4 h-4" /> {company} • <MapPin className="w-4 h-4" /> {location || 'Global'}
                  </p>
                </div>
                {isSharedView && (
                  <div className="px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-bold flex items-center gap-1">
                    <Globe className="w-3 h-3" /> Shared View
                  </div>
                )}
              </div>
              <div className="flex items-center gap-3">
                {reportId && !isSharedView && (
                  <button 
                    onClick={handleShare}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600/20 border border-indigo-500/30 hover:bg-indigo-600/30 transition-colors text-sm font-medium text-indigo-400"
                  >
                    {copied ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
                    {copied ? 'Copied!' : 'Share Link'}
                  </button>
                )}
                <button 
                  onClick={handleExportPdf}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors text-sm font-medium"
                >
                  <Download className="w-4 h-4" /> Export PDF
                </button>
                <button 
                  onClick={handleCopyReport}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors text-sm font-medium"
                  title="Copy raw report data"
                >
                  <Copy className="w-4 h-4" /> Copy Data
                </button>
              </div>
            </div>

            {/* Task 0 & 1: Analysis & Gaps */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <section className="glass-card">
                <div className="flex items-center gap-3 mb-6">
                  <Target className="w-6 h-6 text-indigo-400" />
                  <h3 className="text-2xl font-bold font-display">CV vs JD Gap Analysis</h3>
                </div>
                <div className="space-y-6">
                  <GapList title="Skill Gaps" items={report.task1_gap_analysis.skill_gaps} icon={<Zap className="w-4 h-4 text-pink-400" />} />
                  <GapList title="Experience Gaps" items={report.task1_gap_analysis.experience_gaps} icon={<Briefcase className="w-4 h-4 text-indigo-400" />} />
                  <GapList title="Industry Exposure Gaps" items={report.task1_gap_analysis.industry_exposure_gap} icon={<Globe className="w-4 h-4 text-emerald-400" />} />
                  <GapList title="ATS/Keyword Gaps" items={report.task1_gap_analysis.ats_gaps} icon={<Search className="w-4 h-4 text-amber-400" />} />
                </div>
              </section>

              <section className="glass-card border-red-500/20">
                <div className="flex items-center gap-3 mb-6">
                  <ShieldAlert className="w-6 h-6 text-red-400" />
                  <h3 className="text-2xl font-bold font-display">Risk & Strengths</h3>
                </div>
                <div className="space-y-6">
                  <div className="p-4 rounded-xl bg-red-500/5 border border-red-500/10">
                    <h4 className="text-sm font-bold uppercase tracking-wider text-red-400 mb-3">Risk Areas (Interviewer Focus)</h4>
                    <ul className="space-y-4">
                      {report.task1_gap_analysis.risk_areas.map((item, i) => (
                        <li key={i} className="space-y-2">
                          <div className="flex gap-2 text-slate-200 text-sm font-bold">
                            <span className="text-red-500">•</span> {item.risk}
                          </div>
                          <div className="ml-5 space-y-2">
                            <div className="p-2 rounded bg-slate-900/50 border border-white/5">
                              <p className="text-[10px] font-bold text-slate-500 uppercase">Evidence from CV</p>
                              <p className="text-xs text-slate-400 italic">{item.evidence_from_cv}</p>
                            </div>
                            <div className="p-2 rounded bg-slate-900/50 border border-white/5">
                              <p className="text-[10px] font-bold text-slate-500 uppercase">Potential Impact</p>
                              <p className="text-xs text-slate-400 italic">{item.impact}</p>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/10">
                    <h4 className="text-sm font-bold uppercase tracking-wider text-emerald-400 mb-3">Core Strengths to Emphasize</h4>
                    <ul className="space-y-4">
                      {report.task1_gap_analysis.strengths.map((item, i) => (
                        <li key={i} className="space-y-2">
                          <div className="flex gap-2 text-slate-200 text-sm font-bold">
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" /> {item.strength}
                          </div>
                          <div className="ml-6 space-y-2">
                            <div className="p-2 rounded bg-slate-900/50 border border-white/5">
                              <p className="text-[10px] font-bold text-slate-500 uppercase">Evidence from CV</p>
                              <p className="text-xs text-slate-400 italic">{item.evidence_from_cv}</p>
                            </div>
                            <div className="p-2 rounded bg-slate-900/50 border border-white/5">
                              <p className="text-[10px] font-bold text-slate-500 uppercase">Relevance to JD</p>
                              <p className="text-xs text-slate-400 italic">{item.relevance_to_jd}</p>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </section>
            </div>

            {/* Task 2 & 9: Strategy & Pitch */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <section className="lg:col-span-2 glass-card">
                <div className="flex items-center gap-3 mb-6">
                  <TrendingUp className="w-6 h-6 text-indigo-400" />
                  <h3 className="text-2xl font-bold font-display">Positioning Strategy</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-bold text-slate-200 mb-3">Bridge the Gaps</h4>
                    <ul className="space-y-3">
                      {report.task2_positioning_strategy.gap_bridging.map((item, i) => (
                        <li key={i} className="text-sm text-slate-400 leading-relaxed">{item}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-200 mb-3">Transferable Skills Mapping</h4>
                    <div className="space-y-2">
                      {report.task2_positioning_strategy.transferable_skills.map((item, i) => (
                        <div key={i} className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/50 text-xs">
                          <span className="text-indigo-400 font-medium">{item.from}</span>
                          <ChevronRight className="w-3 h-3 text-slate-600" />
                          <span className="text-pink-400 font-medium">{item.to}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="mt-6 p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
                  <h4 className="text-sm font-bold text-indigo-400 mb-2">Pro Tip: If you don't have X skill...</h4>
                  <p className="text-slate-300 text-sm italic">"{report.task2_positioning_strategy.what_to_say_no_skill}"</p>
                </div>
              </section>

              <section className="glass-card bg-gradient-to-br from-indigo-500/10 to-pink-500/10">
                <div className="flex items-center gap-3 mb-6">
                  <Mic2 className="w-6 h-6 text-pink-400" />
                  <h3 className="text-2xl font-bold font-display">Personal Pitch</h3>
                </div>
                <div className="space-y-6">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">30-Second Version</h4>
                    <p className="text-sm text-slate-300 leading-relaxed bg-slate-950/50 p-3 rounded-lg border border-white/5">{report.task9_personal_pitch.pitch_30s}</p>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">60-Second Version</h4>
                    <p className="text-sm text-slate-300 leading-relaxed bg-slate-950/50 p-3 rounded-lg border border-white/5">{report.task9_personal_pitch.pitch_60s}</p>
                  </div>
                </div>
              </section>
            </div>

            {/* Task 4 & 8: Company Intelligence */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <section className="glass-card">
                <div className="flex items-center gap-3 mb-6">
                  <Building2 className="w-6 h-6 text-amber-400" />
                  <h3 className="text-2xl font-bold font-display">Company Intelligence</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex-1">
                      <h4 className="text-xs font-bold text-slate-500 uppercase mb-1">Business Model</h4>
                      <p className="text-sm text-slate-300">{report.task4_company_intelligence.business_model}</p>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xs font-bold text-slate-500 uppercase mb-1">Market Position</h4>
                      <p className="text-sm text-slate-300">{report.task4_company_intelligence.industry_position}</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Likely Pain Points</h4>
                    <div className="flex flex-wrap gap-2">
                      {report.task4_company_intelligence.pain_points.map((p, i) => (
                        <span key={i} className="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs">
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-white/5">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-xs font-bold text-slate-500 uppercase">Employee Sentiment</h4>
                      <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-xs font-bold">
                        <Sparkles className="w-3 h-3" />
                        {report.task4_company_intelligence.company_reviews.overall_rating.toFixed(1)} / 5.0
                      </div>
                    </div>
                    <p className="text-sm text-slate-400 mb-4 italic">"{report.task4_company_intelligence.company_reviews.sentiment_summary}"</p>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-[10px] font-bold text-emerald-500 uppercase mb-2">Pros</p>
                        <ul className="space-y-1">
                          {report.task4_company_intelligence.company_reviews.pros.slice(0, 3).map((p, i) => (
                            <li key={i} className="text-[11px] text-slate-300 flex gap-1">
                              <span className="text-emerald-500">+</span> {p}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-red-400 uppercase mb-2">Cons</p>
                        <ul className="space-y-1">
                          {report.task4_company_intelligence.company_reviews.cons.slice(0, 3).map((c, i) => (
                            <li key={i} className="text-[11px] text-slate-300 flex gap-1">
                              <span className="text-red-500">-</span> {c}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    {report.task4_company_intelligence.company_reviews.sources.length > 0 && (
                      <div className="mt-4 flex flex-wrap gap-2">
                        {report.task4_company_intelligence.company_reviews.sources.map((s, i) => (
                          <a 
                            key={i} 
                            href={s.uri} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-[10px] text-indigo-400 hover:underline flex items-center gap-1"
                          >
                            <Search className="w-2 h-2" /> {s.title}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </section>

              <section className="glass-card">
                <div className="flex items-center gap-3 mb-6">
                  <Users className="w-6 h-6 text-indigo-400" />
                  <h3 className="text-2xl font-bold font-display">Culture & Mindset</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <h4 className="text-xs font-bold text-slate-500 uppercase mb-1">Culture Style</h4>
                      <p className="text-sm text-slate-300">{report.task8_culture_insights.culture_style}</p>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xs font-bold text-slate-500 uppercase mb-1">Hiring Mindset</h4>
                      <p className="text-sm text-slate-300">{report.task8_culture_insights.hiring_mindset}</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Core Values</h4>
                    <div className="flex flex-wrap gap-2">
                      {report.task8_culture_insights.values.map((v, i) => (
                        <span key={i} className="px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs">
                          {v}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </section>
            </div>

            {/* Task 5: Question Bank */}
            <section className="glass-card">
              <div className="flex items-center gap-3 mb-8">
                <MessageSquare className="w-6 h-6 text-indigo-400" />
                <h3 className="text-3xl font-bold font-display">Interview Question Bank</h3>
              </div>
              
              <div className="space-y-12">
                <QuestionSection title="Technical Questions" questions={report.task5_question_bank.technical} color="indigo" />
                <QuestionSection title="Behavioral (STAR)" questions={report.task5_question_bank.behavioral.map(q => ({ ...q, answer: q.answer_star }))} color="pink" />
                <QuestionSection title="Scenario-Based" questions={report.task5_question_bank.scenario} color="amber" />
                <QuestionSection title="Company-Specific" questions={report.task5_question_bank.company_specific} color="emerald" />
              </div>
            </section>

            {/* Task 6, 7, 10: Final Insights */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <section className="glass-card border-indigo-500/20">
                <h4 className="text-xl font-bold font-display mb-6 flex items-center gap-2">
                  <Loader2 className="w-5 h-5 text-indigo-400" /> Mock Simulation
                </h4>
                <div className="space-y-4">
                  <div>
                    <p className="text-xs font-bold text-slate-500 uppercase mb-2">Rapid Fire</p>
                    <ul className="space-y-2">
                      {report.task6_mock_simulation.rapid_fire.map((q, i) => (
                        <li key={i} className="text-sm text-slate-300">• {q}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                    <p className="text-xs font-bold text-red-400 uppercase mb-1">Pressure Question</p>
                    <p className="text-sm text-slate-200">{report.task6_mock_simulation.pressure_question}</p>
                  </div>
                </div>
              </section>

              <section className="glass-card border-pink-500/20">
                <h4 className="text-xl font-bold font-display mb-6 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-pink-400" /> Selection Traits
                </h4>
                <div className="space-y-4">
                  <div className="space-y-2">
                    {report.task7_selection_rejection.selection_traits.map((t, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm text-emerald-400">
                        <CheckCircle2 className="w-4 h-4 shrink-0" /> {t}
                      </div>
                    ))}
                  </div>
                  <div className="pt-4 border-t border-white/5">
                    <p className="text-xs font-bold text-slate-500 uppercase mb-2">Top Rejection Reasons</p>
                    <ul className="space-y-2">
                      {report.task7_selection_rejection.rejection_reasons.map((r, i) => (
                        <li key={i} className="text-sm text-slate-400">• {r}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </section>

              <section className="glass-card border-amber-500/20">
                <h4 className="text-xl font-bold font-display mb-6 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-amber-400" /> Benchmarking
                </h4>
                <div className="space-y-4">
                  <div>
                    <p className="text-xs font-bold text-emerald-400 uppercase mb-2">Top 10% Candidates</p>
                    <ul className="space-y-2">
                      {report.task10_benchmarking.top_10_percent.map((b, i) => (
                        <li key={i} className="text-sm text-slate-300">• {b}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-red-400 uppercase mb-2">Common Mistakes</p>
                    <ul className="space-y-2">
                      {report.task10_benchmarking.average_mistakes.map((m, i) => (
                        <li key={i} className="text-sm text-slate-400">• {m}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </section>
            </div>

            {/* Suggested Organizations */}
            <section className="glass-card mb-12">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <Globe className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold font-display">Suggested Organizations</h2>
                  <p className="text-slate-400 text-sm">Relevant companies in {location || 'your region'} for {role || 'this role'}</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {report.suggested_organizations.map((org, i) => (
                  <div key={i} className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 hover:border-emerald-500/30 transition-all group">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-bold text-white group-hover:text-emerald-400 transition-colors">{org.name}</h3>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 uppercase tracking-wider">
                        {org.relevance_score}% Match
                      </span>
                    </div>
                    <p className="text-sm text-slate-400 mb-3 line-clamp-2">{org.reasoning}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-500">{org.location}</span>
                      <a 
                        href={`https://www.google.com/search?q=${encodeURIComponent(org.name + ' careers')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs font-bold text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-1"
                      >
                        View Jobs <ArrowRight className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <div className="text-center pt-8">
              <button 
                onClick={() => {
                  setReport(null);
                  window.scrollTo(0, 0);
                }}
                className="px-8 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition-all"
              >
                Start New Analysis
              </button>
            </div>
          </motion.div>
        )}
      </main>

      {/* Scroll to Top */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-8 right-8 z-50 p-4 rounded-full bg-indigo-600 text-white shadow-lg hover:bg-indigo-500 transition-all"
            title="Scroll to top"
          >
            <ChevronRight className="w-6 h-6 -rotate-90" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* History Overlay */}
      <AnimatePresence>
        {showHistory && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
            >
              <div className="p-6 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <History className="w-6 h-6 text-indigo-400" />
                  <h2 className="text-xl font-bold font-display">Your Report History</h2>
                </div>
                <div className="flex items-center gap-2">
                  {pastReports.length > 0 && (
                    <button 
                      onClick={handleClearAllHistory}
                      className="text-xs font-bold text-red-400 hover:text-red-300 transition-colors px-3 py-1 rounded-lg hover:bg-red-500/10"
                    >
                      Clear All
                    </button>
                  )}
                  <button 
                    onClick={() => setShowHistory(false)}
                    className="p-2 rounded-full hover:bg-slate-800 transition-colors"
                  >
                    <ChevronRight className="w-6 h-6 rotate-90" />
                  </button>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {pastReports.length === 0 ? (
                  <div className="text-center py-12 text-slate-500">
                    <History className="w-12 h-12 mx-auto mb-4 opacity-20" />
                    <p>No reports saved yet.</p>
                  </div>
                ) : (
                  pastReports.map((pr) => (
                    <button
                      key={pr.id}
                      onClick={() => handleSelectReport(pr)}
                      className="w-full text-left p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-indigo-500/50 transition-all group"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-bold text-white group-hover:text-indigo-400 transition-colors">{pr.role}</h3>
                        <span className="text-xs text-slate-500">{new Date(pr.createdAt).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-slate-400">
                        <div className="flex items-center gap-1">
                          <Building2 className="w-4 h-4" />
                          <span>{pr.company}</span>
                        </div>
                        {pr.location && (
                          <div className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            <span>{pr.location}</span>
                          </div>
                        )}
                      </div>
                      <button 
                        onClick={(e) => handleDeleteReport(pr.id, e)}
                        className="p-2 rounded-lg hover:bg-red-500/20 text-slate-500 hover:text-red-400 transition-colors"
                        title="Delete report"
                      >
                        <LogOut className="w-4 h-4 rotate-90" />
                      </button>
                    </button>
                  ))
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function GapList({ title, items, icon }: { title: string, items: any[], icon: ReactNode }) {
  return (
    <div>
      <h4 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-2">
        {icon} {title}
      </h4>
      <ul className="space-y-4">
        {items.map((item, i) => (
          <li key={i} className="space-y-1">
            <div className="flex gap-2 text-slate-200 text-sm font-bold">
              <span className="text-indigo-500">•</span> {item.gap}
            </div>
            <div className="ml-5 grid grid-cols-1 md:grid-cols-2 gap-2">
              <div className="p-2 rounded bg-slate-900/50 border border-white/5">
                <p className="text-[10px] font-bold text-slate-500 uppercase">JD Requirement</p>
                <p className="text-xs text-slate-400 italic">{item.jd_requirement}</p>
              </div>
              <div className="p-2 rounded bg-slate-900/50 border border-white/5">
                <p className="text-[10px] font-bold text-slate-500 uppercase">CV Status</p>
                <p className="text-xs text-slate-400 italic">{item.cv_status}</p>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Tooltip({ children, text }: { children: ReactNode, text: string }) {
  const [show, setShow] = useState(false);
  
  return (
    <div className="relative inline-block w-full" onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
      {children}
      <AnimatePresence>
        {show && (
          <motion.div
            initial={{ opacity: 0, y: 5, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 5, scale: 0.95 }}
            className="absolute z-[110] bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs font-medium shadow-2xl whitespace-normal min-w-[200px] pointer-events-none"
          >
            <div className="flex items-start gap-2">
              <Info className="w-3 h-3 text-indigo-400 shrink-0 mt-0.5" />
              <p>{text}</p>
            </div>
            <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-slate-800" />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function QuestionSection({ title, questions, color }: { title: string, questions: any[], color: string }) {
  const colorClasses: any = {
    indigo: "text-indigo-400 bg-indigo-500/10 border-indigo-500/20",
    pink: "text-pink-400 bg-pink-500/10 border-pink-500/20",
    amber: "text-amber-400 bg-amber-500/10 border-amber-500/20",
    emerald: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  };

  return (
    <div>
      <h4 className={`inline-block px-4 py-1 rounded-full text-sm font-bold uppercase tracking-widest mb-6 ${colorClasses[color]}`}>
        {title}
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {questions.map((q, i) => (
          <div key={i} className="p-5 rounded-2xl bg-slate-900/50 border border-white/5 space-y-4">
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase mb-1">Question</p>
              <p className="font-bold text-slate-200">{q.question}</p>
            </div>
            <div>
              <p className="text-xs font-bold text-slate-500 uppercase mb-1">Smart Answer</p>
              <p className="text-sm text-slate-300 leading-relaxed">{q.answer}</p>
            </div>
            <div className="pt-3 border-t border-white/5">
              <p className="text-xs font-bold text-slate-500 uppercase mb-1">Logic / Why this works</p>
              <p className="text-xs text-slate-400 italic">{q.logic}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
