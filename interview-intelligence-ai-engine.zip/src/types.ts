export interface InterviewReport {
  task0_data_extraction: {
    cv_summary: {
      skills: string[];
      experience: string[];
      tools: string[];
      industry: string;
      achievements: string[];
    };
    jd_summary: {
      skills: string[];
      experience: string[];
      tools: string[];
      industry: string;
      key_requirements: string[];
    };
    missing_data: string[];
  };
  task1_gap_analysis: {
    skill_gaps: { gap: string; jd_requirement: string; cv_status: string }[];
    experience_gaps: { gap: string; jd_requirement: string; cv_status: string }[];
    industry_exposure_gap: { gap: string; jd_requirement: string; cv_status: string }[];
    ats_gaps: { gap: string; jd_requirement: string; cv_status: string }[];
    risk_areas: { risk: string; evidence_from_cv: string; impact: string }[];
    strengths: { strength: string; evidence_from_cv: string; relevance_to_jd: string }[];
  };
  task2_positioning_strategy: {
    gap_bridging: string[];
    repositioning_tips: string[];
    transferable_skills: { from: string; to: string }[];
    what_to_say_no_skill: string;
  };
  task3_cv_upgrade: {
    rewrite_suggestions: string[];
    ai_tools: string[];
    bullet_examples: { original: string; optimized: string }[];
    keywords: string[];
  };
  task4_company_intelligence: {
    business_model: string;
    industry_position: string;
    pain_points: string[];
    company_reviews: {
      overall_rating: number;
      pros: string[];
      cons: string[];
      sentiment_summary: string;
      sources: { title: string; uri: string }[];
    };
  };
  task5_question_bank: {
    technical: { question: string; answer: string; logic: string }[];
    behavioral: { question: string; answer_star: string; logic: string }[];
    scenario: { question: string; answer: string; logic: string }[];
    company_specific: { question: string; answer: string; logic: string }[];
  };
  task6_mock_simulation: {
    rapid_fire: string[];
    case_scenarios: string[];
    pressure_question: string;
  };
  task7_selection_rejection: {
    rejection_reasons: string[];
    selection_traits: string[];
  };
  task8_culture_insights: {
    culture_style: string;
    hiring_mindset: string;
    values: string[];
    faqs: string[];
  };
  task9_personal_pitch: {
    pitch_30s: string;
    pitch_60s: string;
  };
  task10_benchmarking: {
    top_10_percent: string[];
    average_mistakes: string[];
  };
  suggested_organizations: {
    name: string;
    reason: string;
    location: string;
    website: string;
  }[];
}
