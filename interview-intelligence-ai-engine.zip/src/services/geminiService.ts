import { GoogleGenAI, Type } from "@google/genai";
import { InterviewReport } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function generateInterviewReport(
  cv: string,
  jd: string,
  company: string,
  role: string,
  location: string,
  jdUrl?: string
): Promise<InterviewReport> {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `You are the "Interview Intelligence AI Engine", an elite career strategist, ex-hiring manager, and recruiter with 15+ years of experience.
Your goal is to provide a deep, actionable, and elite-level interview preparation intelligence report.
Think like a hiring manager, not a coach. Be practical, specific, and avoid generic advice.

Input provided:
- Candidate CV
- Job Description (JD)
- Company Name
- Role
- Location

You must use the googleSearch tool to find real-time company intelligence, employee sentiment, and culture reviews (e.g., from Glassdoor, Indeed, or LinkedIn) to provide an accurate 'Company Reviews' section.
You must also use the googleSearch tool to find 5-10 suggested organizations to apply for a job according to the candidate's location (region, city, and country) and role.

CRITICAL QUANTITY REQUIREMENTS:
- Technical Questions: Provide at least 10 high-quality technical questions with logical answers.
- Behavioral Questions: Provide at least 5 behavioral questions with STAR-method answers.
- Scenario-based Questions: Provide at least 3 scenario-based Q&A.
- Company Pain Points: Identify at least 5 specific organizational pain points.
- Rapid-fire Questions: Provide at least 7 rapid-fire questions for the mock simulation.

You must output a valid JSON object matching the requested schema.`;

  const prompt = `Generate a complete interview intelligence report for:
Company: ${company}
Role: ${role}
Location: ${location}

CV Content:
${cv}

JD Content:
${jd}
${jdUrl ? `JD URL: ${jdUrl}` : ''}`;

  const response = await ai.models.generateContent({
    model,
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      tools: [
        { googleSearch: {} },
        ...(jdUrl ? [{ urlContext: {} }] : [])
      ],
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          task0_data_extraction: {
            type: Type.OBJECT,
            properties: {
              cv_summary: {
                type: Type.OBJECT,
                properties: {
                  skills: { type: Type.ARRAY, items: { type: Type.STRING } },
                  experience: { type: Type.ARRAY, items: { type: Type.STRING } },
                  tools: { type: Type.ARRAY, items: { type: Type.STRING } },
                  industry: { type: Type.STRING },
                  achievements: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: ["skills", "experience", "tools", "industry", "achievements"],
              },
              jd_summary: {
                type: Type.OBJECT,
                properties: {
                  skills: { type: Type.ARRAY, items: { type: Type.STRING } },
                  experience: { type: Type.ARRAY, items: { type: Type.STRING } },
                  tools: { type: Type.ARRAY, items: { type: Type.STRING } },
                  industry: { type: Type.STRING },
                  key_requirements: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: ["skills", "experience", "tools", "industry", "key_requirements"],
              },
              missing_data: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["cv_summary", "jd_summary", "missing_data"],
          },
          task1_gap_analysis: {
            type: Type.OBJECT,
            properties: {
              skill_gaps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    gap: { type: Type.STRING },
                    jd_requirement: { type: Type.STRING },
                    cv_status: { type: Type.STRING },
                  },
                  required: ["gap", "jd_requirement", "cv_status"],
                },
              },
              experience_gaps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    gap: { type: Type.STRING },
                    jd_requirement: { type: Type.STRING },
                    cv_status: { type: Type.STRING },
                  },
                  required: ["gap", "jd_requirement", "cv_status"],
                },
              },
              industry_exposure_gap: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    gap: { type: Type.STRING },
                    jd_requirement: { type: Type.STRING },
                    cv_status: { type: Type.STRING },
                  },
                  required: ["gap", "jd_requirement", "cv_status"],
                },
              },
              ats_gaps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    gap: { type: Type.STRING },
                    jd_requirement: { type: Type.STRING },
                    cv_status: { type: Type.STRING },
                  },
                  required: ["gap", "jd_requirement", "cv_status"],
                },
              },
              risk_areas: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    risk: { type: Type.STRING },
                    evidence_from_cv: { type: Type.STRING },
                    impact: { type: Type.STRING },
                  },
                  required: ["risk", "evidence_from_cv", "impact"],
                },
              },
              strengths: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    strength: { type: Type.STRING },
                    evidence_from_cv: { type: Type.STRING },
                    relevance_to_jd: { type: Type.STRING },
                  },
                  required: ["strength", "evidence_from_cv", "relevance_to_jd"],
                },
              },
            },
            required: ["skill_gaps", "experience_gaps", "industry_exposure_gap", "ats_gaps", "risk_areas", "strengths"],
          },
          task2_positioning_strategy: {
            type: Type.OBJECT,
            properties: {
              gap_bridging: { type: Type.ARRAY, items: { type: Type.STRING } },
              repositioning_tips: { type: Type.ARRAY, items: { type: Type.STRING } },
              transferable_skills: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    from: { type: Type.STRING },
                    to: { type: Type.STRING },
                  },
                  required: ["from", "to"],
                },
              },
              what_to_say_no_skill: { type: Type.STRING },
            },
            required: ["gap_bridging", "repositioning_tips", "transferable_skills", "what_to_say_no_skill"],
          },
          task3_cv_upgrade: {
            type: Type.OBJECT,
            properties: {
              rewrite_suggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
              ai_tools: { type: Type.ARRAY, items: { type: Type.STRING } },
              bullet_examples: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    original: { type: Type.STRING },
                    optimized: { type: Type.STRING },
                  },
                  required: ["original", "optimized"],
                },
              },
              keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["rewrite_suggestions", "ai_tools", "bullet_examples", "keywords"],
          },
          task4_company_intelligence: {
            type: Type.OBJECT,
            properties: {
              business_model: { type: Type.STRING },
              industry_position: { type: Type.STRING },
              pain_points: { type: Type.ARRAY, items: { type: Type.STRING } },
              company_reviews: {
                type: Type.OBJECT,
                properties: {
                  overall_rating: { type: Type.NUMBER },
                  pros: { type: Type.ARRAY, items: { type: Type.STRING } },
                  cons: { type: Type.ARRAY, items: { type: Type.STRING } },
                  sentiment_summary: { type: Type.STRING },
                  sources: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        title: { type: Type.STRING },
                        uri: { type: Type.STRING },
                      },
                      required: ["title", "uri"],
                    },
                  },
                },
                required: ["overall_rating", "pros", "cons", "sentiment_summary", "sources"],
              },
            },
            required: ["business_model", "industry_position", "pain_points", "company_reviews"],
          },
          task5_question_bank: {
            type: Type.OBJECT,
            properties: {
              technical: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    answer: { type: Type.STRING },
                    logic: { type: Type.STRING },
                  },
                  required: ["question", "answer", "logic"],
                },
              },
              behavioral: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    answer_star: { type: Type.STRING },
                    logic: { type: Type.STRING },
                  },
                  required: ["question", "answer_star", "logic"],
                },
              },
              scenario: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    answer: { type: Type.STRING },
                    logic: { type: Type.STRING },
                  },
                  required: ["question", "answer", "logic"],
                },
              },
              company_specific: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    answer: { type: Type.STRING },
                    logic: { type: Type.STRING },
                  },
                  required: ["question", "answer", "logic"],
                },
              },
            },
            required: ["technical", "behavioral", "scenario", "company_specific"],
          },
          task6_mock_simulation: {
            type: Type.OBJECT,
            properties: {
              rapid_fire: { type: Type.ARRAY, items: { type: Type.STRING } },
              case_scenarios: { type: Type.ARRAY, items: { type: Type.STRING } },
              pressure_question: { type: Type.STRING },
            },
            required: ["rapid_fire", "case_scenarios", "pressure_question"],
          },
          task7_selection_rejection: {
            type: Type.OBJECT,
            properties: {
              rejection_reasons: { type: Type.ARRAY, items: { type: Type.STRING } },
              selection_traits: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["rejection_reasons", "selection_traits"],
          },
          task8_culture_insights: {
            type: Type.OBJECT,
            properties: {
              culture_style: { type: Type.STRING },
              hiring_mindset: { type: Type.STRING },
              values: { type: Type.ARRAY, items: { type: Type.STRING } },
              faqs: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["culture_style", "hiring_mindset", "values", "faqs"],
          },
          task9_personal_pitch: {
            type: Type.OBJECT,
            properties: {
              pitch_30s: { type: Type.STRING },
              pitch_60s: { type: Type.STRING },
            },
            required: ["pitch_30s", "pitch_60s"],
          },
          task10_benchmarking: {
            type: Type.OBJECT,
            properties: {
              top_10_percent: { type: Type.ARRAY, items: { type: Type.STRING } },
              average_mistakes: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["top_10_percent", "average_mistakes"],
          },
          suggested_organizations: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                reason: { type: Type.STRING },
                location: { type: Type.STRING },
                website: { type: Type.STRING },
              },
              required: ["name", "reason", "location", "website"],
            },
          },
        },
        required: [
          "task0_data_extraction",
          "task1_gap_analysis",
          "task2_positioning_strategy",
          "task3_cv_upgrade",
          "task4_company_intelligence",
          "task5_question_bank",
          "task6_mock_simulation",
          "task7_selection_rejection",
          "task8_culture_insights",
          "task9_personal_pitch",
          "task10_benchmarking",
          "suggested_organizations",
        ],
      },
    },
  });

  return JSON.parse(response.text);
}

export async function extractJdDetails(jdText: string, jdUrl?: string): Promise<{ company: string; role: string; location: string }> {
  const model = "gemini-3-flash-preview";
  const systemInstruction = "You are an expert recruitment assistant. Extract the Company Name, Job Title/Role, and Location from the provided Job Description text or URL. If any field is missing, return an empty string for that field. Return a valid JSON object.";
  
  const prompt = `Extract details from this JD:
  Text: ${jdText}
  ${jdUrl ? `URL: ${jdUrl}` : ''}`;

  const response = await ai.models.generateContent({
    model,
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          company: { type: Type.STRING },
          role: { type: Type.STRING },
          location: { type: Type.STRING },
        },
        required: ["company", "role", "location"],
      },
    },
  });

  return JSON.parse(response.text);
}
